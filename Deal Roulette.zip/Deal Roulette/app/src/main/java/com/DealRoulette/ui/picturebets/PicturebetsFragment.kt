package com.DealRoulette.ui.picturebets

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.DealRoulette.R

class PicturebetsFragment : Fragment() {

    private lateinit var picturebetsViewModel: PicturebetsViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        picturebetsViewModel =
                ViewModelProviders.of(this).get(PicturebetsViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_picturebets, container, false)
        val textView: TextView = root.findViewById(R.id.text_picturebets)
        picturebetsViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        return root
    }
}
