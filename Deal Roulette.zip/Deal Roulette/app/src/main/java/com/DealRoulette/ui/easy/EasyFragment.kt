package com.DealRoulette.ui.easy

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.DealRoulette.R
import com.DealRoulette.ui.home.HomeViewModel

class EasyFragment : Fragment() {

    private lateinit var easyViewModel: EasyViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        easyViewModel =
            ViewModelProviders.of(this).get(EasyViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_easy, container, false)
        val textView: TextView = root.findViewById(R.id.text_easy)
        easyViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        return root
    }
}