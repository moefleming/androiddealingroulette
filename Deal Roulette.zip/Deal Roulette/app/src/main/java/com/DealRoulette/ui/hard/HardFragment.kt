package com.DealRoulette.ui.hard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.DealRoulette.R
import com.DealRoulette.ui.home.HomeViewModel
import kotlinx.android.synthetic.*
import kotlinx.android.synthetic.main.nav_header_main.*

class HardFragment : Fragment() {

    private lateinit var hardViewModel: HardViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        hardViewModel =
            ViewModelProviders.of(this).get(HardViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_hard, container, false)
        val textView: TextView = root.findViewById(R.id.text_hard)
        hardViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        return root
    }
}
